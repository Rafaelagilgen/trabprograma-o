<footer>
    <p>Endereço</p>
    <p>Telefone</p>
</footer>

</body>
</html>